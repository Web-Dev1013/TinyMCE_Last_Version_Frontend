import { Component, OnInit } from '@angular/core';
import { VenderService } from './../vender.service';
import { HttpEventType, HttpResponse } from '@angular/common/http';

declare var tinyMCE: any;
@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {

  constructor(private venderService: VenderService) {
  }

  ngOnInit(): void {
    let subThis = this;
    tinyMCE.init({
      selector: "#editor",
      height: 300,
      menubar: true,
      plugins: [
        'advlist autolink lists image link charmap print preview anchor',
        'searchreplace visualblocks code fullscreen',
        'insertdatetime media table paste code help wordcount'
      ],
      toolbar: 'undo redo |\
          forecolor image backcolor|\
          bold italic underline strikethrough |\
          alignleft aligncenter alignright alignjustify |\
          insertfile media anchor codesample |\
          fontselect fontsizeselect |\ template formatselect |\
          outdent indent |  numlist bullist  charmap emoticons |\
          | fullscreen link pagebreak removeformat preview save print |\
          ltr rtl',
      autosave_ask_before_unload: true,
      autosave_interval: '30s',
      autosave_prefix: '{path}{query}-{id}-',
      autosave_restore_when_empty: false,
      autosave_retention: '2m',
      image_advtab: true,
      importcss_append: true,
      toolbar_sticky: true,
      template_cdate_format: '[Date Created (CDATE): %m/%d/%Y : %H:%M:%S]',
      template_mdate_format: '[Date Modified (MDATE): %m/%d/%Y : %H:%M:%S]',
      image_caption: true,
      quickbars_selection_toolbar: 'bold italic | quicklink h2 h3 blockquote quickimage quicktable',
      noneditable_noneditable_class: 'mceNonEditable',
      toolbar_mode: 'sliding',
      contextmenu: 'link image imagetools table',
      skin: this.useDarkMode ? 'oxide-dark' : 'oxide',
      content_css: this.useDarkMode ? 'dark' : 'default',
      automatic_uploads: this.uploadFlag?true:false,
      external_image_list_url : "logo", 
      paste_data_images: true,
      file_picker_types: "image",
      location: subThis.imageUrl,
      
      file_picker_callback: function(callback:any, value:any, meta:any) {
        let url:string = subThis.imageUrl || "";
        console.log(url);
        (<HTMLInputElement>document.querySelector("input[type=url]")).value = url;
        
        let sourceBtn: HTMLElement = document.querySelector("[title=source]") as HTMLElement;
        console.log(sourceBtn);
        sourceBtn.click();
      },
      images_upload_handler: function (blobInfo: any, success: any, failure: any) {
        setTimeout(function () {
          console.log("+++++++++++++", subThis.imageUrl)
          /* no matter what you upload, we will turn it into TinyMCE logo :)*/
          success(subThis.imageUrl);
        }, 2000);
      },
      content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
    }).then(function () {
      let uploadBtn = document.createElement("button");
      uploadBtn.setAttribute("data-toggle", "modal");
      uploadBtn.setAttribute("data-target", "#uploadModal");
      let uploadIcon = '<span class="tox-icon tox-tbtn__icon-wrap"><svg width="24" height="24"><path d="M5 15.7l3.3-3.2c.3-.3.7-.3 1 0L12 15l4.1-4c.3-.4.8-.4 1 0l2 1.9V5H5v10.7zM5 18V19h3l2.8-2.9-2-2L5 17.9zm14-3l-2.5-2.4-6.4 6.5H19v-4zM4 3h16c.6 0 1 .4 1 1v16c0 .6-.4 1-1 1H4a1 1 0 01-1-1V4c0-.6.4-1 1-1zm6 8a2 2 0 100-4 2 2 0 000 4z" fill-rule="nonzero"></path></svg></span>';
      uploadBtn.innerHTML = uploadIcon;
      uploadBtn.classList.add("tox-tbtn");
      let parentElements = document.getElementsByClassName("tox-toolbar__group")[1];
      parentElements.appendChild(uploadBtn);

    });

    // Init Image data
    this.getListFiles();
  }

  uploadFlag: boolean = false;
  initData: any[] = [];
  selectedFiles?: FileList;
  progressInfos: any[] = [];
  message: string[] = [];
  useDarkMode: boolean = true;
  imageUrl?: string;
  replaceId: any = 0;
  fileInfos: any[] = [];
  image_type: string = "";
  image_name: string = "";
  image_size: string = "";
  baseUrl: string = 'http://localhost:8080/api/files/';

  // Create upload button in tinyMCE plugin
  uploadImage(event: any) {
    this.replaceId = 0;
    this.selectedFiles = event.target.files;
    this.message = [];
    this.progressInfos = [];
    this.uploadFiles();
  }

  replaceImage(event: any) {
    this.selectedFiles = event.target.files;
    this.replaceId = event.target.id;
    this.message = [];
    this.progressInfos = [];
    this.uploadFiles();
  }

  getListFiles(): void {
    this.venderService.getListFiles().subscribe(
      (res: any) => {
        const subThis = this;
        if (res.body != undefined) {
          subThis.initData = [];
          res.body.imageInfos.map(function (item: any, index: any) {
            subThis.initData.push(item);
          });
        }
      },
      (error: any) => {
        console.log(error);
      });
  }
  //uploading selected files
  uploadFiles(): void {
    // console.log(area);
    this.message = [];
    if (this.selectedFiles) {
      for (let i = 0; i < this.selectedFiles.length; i++) {
        // this.upload(i, this.selectedFiles[i]);
        this.image_name = this.selectedFiles[i].name;
        this.imageUrl = "assets/upload_files/" + this.selectedFiles[i].name;
        this.image_type = this.selectedFiles[i].type;
        this.image_size = this.selectedFiles[i].size + "bytes";
      }
      let imageBtn = <HTMLButtonElement>document.querySelectorAll(".tox-tbtn")[4];
      imageBtn.click();
      let sourceBtn = <HTMLButtonElement>document.querySelectorAll(".tox-browse-url")[0];
      console.log("===", sourceBtn);
      sourceBtn.click();
    }
  }

  //upload method
  upload(idx: number, file: File): void {
    this.progressInfos[idx] = { value: 0, fileName: file.name };
    this.imageUrl = '';
    if (file) {
      this.venderService.upload(file, this.replaceId).subscribe(
        (event: any) => {
          if (event.type === HttpEventType.UploadProgress) {
            this.progressInfos[idx].value = Math.round(100 * event.loaded / event.total);
          } else if (event instanceof HttpResponse) {
            const msg = 'Uploaded the file successfully: ' + file.name;
            this.message.push(msg);
            this.fileInfos.push({ name: file.name, url: this.baseUrl + file.name });
            this.imageUrl = this.imageUrl + file.name + ":";
          }
          this.getListFiles();
        },
        (err: any) => {
          this.progressInfos[idx].value = 0;
          const msg = 'Could not upload the file: ' + file.name;
          this.message.push(msg);
          this.fileInfos.push(file.name);
        });
    }
  }
}
